# 1

Jenivaldson gosta muito de ler, devora um livro atrás do outro. Jenivaldson tem uma curiosidade: qual a sua velocidade de leitura? Escreva um programa em JavaScript que solicite a quantidade de livros que Jenivaldson já leu e a quantidade de meses que já se passaram desde seu primeiro livro, e mostre quantos livros/mê s ele lê.

# 2

Em um game o jogador precisa eliminar 150 monstros para subir cada nível. Escreva um programa em JavaScript que pergunte quantos monstros o jogador já eliminou e calcule e mostre na tela em qual nível ele está.

# 3

A famosíssima banda de rock Metaleiros of Metal tem uma tradição nos seus shows: toca uma música a cada 1200 pessoas presentes no show. Escreva um programa em JavaScript para ajudar os Metaleiros of Metal a saber quantas músicas eles precisam tocar. O programa precisa solicitar a quantidade de pessoas presentes e deve informar quantas músicas a banda deverá tocar.

# 4

Mardiscléia é vendedora e recebe um valor fixo de R$ 500,00 mais R$ 50,00 por cada venda realizada. Escreva um programa em JavaScript que pergunte quantas vendas Mardiscléia realizou no mês e informe o valor total que ela deverá receber.

# 5

Osvlédson desenvolveu um website que recebe centenas de visitas diariamente. Aproveitando seu sucesso, Osvlédson inscreveu o site nos anúncios do Google. O Google vai pagar R$ 0,02 por cada clique nos anúncios do site. Escreva um programa em JavaScript que ajude Osvlédson a saber quanto ele pode lucrar. O programa deve solicitar o valor que Osvlédson deseja ganhar e deve informar quantos cliques são necessários para que ele receba o valor desejado.

# 6

Juracildo mora a 3 km de distâ n cia da escola onde estuda e vai pra aula a pé todos os dias. Ele quer saber a distâ n cia média em cent ím etros e o tempo médio de cada um de seus passos. Escreva um programa em JavaScript que pergunte quantos minutos Juracildo leva para chegar à escola e quantos passos ele dá do início ao fim de seu trajeto, e mostre na tela quantos centímetros tem cada passo e quantos segundos dura cada passo de Juracildo.

# 7

Escreva um programa em JavaScript que receba o nome de dois usuários, inverta-os entre variáveis, e mostre-os na tela.

# 8

Faça um programa em JavaScript que, dada a idade do usuário em anos, calcule quantas horas ele viveu, aproximadamente
